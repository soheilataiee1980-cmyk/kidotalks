/* Kidotalks - Family and Friends 2 learning widget. */
(function () {
  "use strict";
  const mount = document.getElementById("kidotalk-book2");
  if (!mount) return;
  const scriptUrl = document.currentScript && document.currentScript.src;
  const dataUrl = mount.dataset.courseData || new URL("family-friends-2-course-pack.json", scriptUrl || location.href).href;
  const storageKey = "kidotalk-family-friends-2-progress-v1";
  const esc = value => String(value == null ? "" : value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const mix = items => { const a = items.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const artMap = [
    ["pencil case","✏️"],["computer","💻"],["coat hook","🧥"],["board","📋"],["classroom","🏫"],["school yard","🏫"],["art room","🎨"],["computer room","💻"],["gym","🤸"],["school","🏫"],
    ["table","🪑"],["chair","🪑"],["poster","🖼️"],["picture","🖼️"],["drawers","🗄️"],["cabinet","🗄️"],["cd player","📻"],["shelf","📚"],["bedroom","🛏️"],["bed","🛏️"],["pillow","🛏️"],["blanket","🛌"],["sock","🧦"],
    ["happy","😄"],["sad","😢"],["angry","😠"],["scared","😨"],["nervous","😬"],["brave","🦸"],["tired","🥱"],["hungry","😋"],["thirsty","🥤"],["cold","🥶"],["hot","🥵"],
    ["bike","🚲"],["horse","🐎"],["skateboard","🛹"],["skate","🛼"],["tennis","🎾"],["soccer","⚽"],["ball","⚽"],
    ["milkshake","🥤"],["sandwich","🥪"],["cheese","🧀"],["fries","🍟"],["pizza","🍕"],["salad","🥗"],["chicken","🍗"],["apple","🍎"],["apples","🍎"],["banana","🍌"],["bananas","🍌"],["orange","🍊"],["oranges","🍊"],["cake","🎂"],["chocolate","🍫"],["candy","🍬"],["balloon","🎈"],["present","🎁"],["card","💌"],["tie","👔"],["pastries","🥐"],["nuts","🥜"],
    ["art","🎨"],["math","🔢"],["science","🔬"],["english","🔤"],["music","🎵"],["p.e.","⚽"],["homework","📒"],["grandma","👵"],["swimming","🏊"],["tv","📺"],["email","📧"],["book","📖"],["breakfast","🍳"],["dinner","🍽️"],["get up","🌅"],["go to bed","🌙"],["clock","🕒"],["morning","🌅"],["afternoon","☀️"],["evening","🌆"],["night","🌙"],
    ["doctor","🧑‍⚕️"],["teacher","🧑‍🏫"],["police","👮"],["firefighter","🧑‍🚒"],["hospital","🏥"],["airport","✈️"],["station","🚉"],["zoo","🦁"],["supermarket","🛒"],["bank","🏦"],["garage","🚗"],["store","🏪"],
    ["sunny","☀️"],["windy","🌬️"],["raining","🌧️"],["rain","🌧️"],["snowing","🌨️"],["snowman","⛄"],["kite","🪁"],["coat","🧥"],["gloves","🧤"],["scarf","🧣"],["jeans","👖"],["boots","🥾"],["skirt","👗"],["shirt","👕"],
    ["wedding","💒"],["bride","👰"],["guest","🧑‍🤝‍🧑"],["band","🎸"],["invitation","💌"],["dance","💃"],["sleep","😴"],["photo","📷"],["camera","📷"],
    ["cow","🐄"],["goat","🐐"],["sheep","🐑"],["donkey","🫏"],["goose","🪿"],["farm","🚜"],["camel","🐪"],["sand dune","🏜️"],["desert","🏜️"],["plant","🌱"],["leaf","🍃"],["rock","🪨"],
    ["heart","❤️"],["oxygen","🫁"],["muscles","💪"],["exercise","🏃"],["water","💧"],["float","🛟"],["sink","⚓"],["air","💨"],["light","🪶"],["heavy","🏋️"],
    ["family","👨‍👩‍👧"],["children","🧒"],["child","🧒"],["man","👨"],["woman","👩"],["first","🥇"],["second","🥈"],["third","🥉"],["fourth","4️⃣"]
  ];
  function illustration(word) {
    const key = String(word || "").toLowerCase().trim();
    const match = artMap.find(([term]) => key === term) || artMap.find(([term]) => key.includes(term));
    return match ? match[1] : "✨";
  }

  const style = document.createElement("style");
  style.textContent = `
    #kidotalk-book2{--ink:#263653;--blue:#426bb2;--purple:#7652aa;--teal:#178b85;--yellow:#ffcf5a;--line:#dce4f4;--soft:#f5f7ff;color:var(--ink);font-family:inherit;line-height:1.75}
    #kidotalk-book2 *{box-sizing:border-box}#kidotalk-book2 button,#kidotalk-book2 select,#kidotalk-book2 textarea{font:inherit;color:inherit}
    #kidotalk-book2 .b2-shell{max-width:1080px;margin:24px auto;padding:clamp(14px,3vw,28px);border:1px solid var(--line);border-radius:28px;background:linear-gradient(145deg,#f8faff,#fff 58%,#faf6ff);box-shadow:0 16px 45px #334b7912}
    #kidotalk-book2 .b2-head{display:flex;align-items:center;gap:16px;padding:20px;border-radius:22px;color:#fff;background:linear-gradient(120deg,var(--blue),var(--purple))}#kidotalk-book2 .b2-mark{display:grid;place-items:center;width:58px;height:58px;flex:none;border-radius:18px;background:#ffffff24;font-size:31px}#kidotalk-book2 h1,#kidotalk-book2 h2,#kidotalk-book2 h3,#kidotalk-book2 p{margin-top:0}#kidotalk-book2 h1{margin-bottom:2px;font-size:clamp(21px,3vw,30px)}#kidotalk-book2 .b2-head p{margin:0;opacity:.9}
    #kidotalk-book2 .b2-progress{margin:16px 0 20px;padding:14px 16px;border:1px solid var(--line);border-radius:17px;background:#fff}#kidotalk-book2 .b2-progress-top{display:flex;justify-content:space-between;gap:12px;align-items:center;font-weight:700}#kidotalk-book2 .b2-progress-track{height:10px;margin-top:8px;overflow:hidden;border-radius:999px;background:#e8eaf2}#kidotalk-book2 .b2-progress-track i{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#64c5a4,#8070d3);transition:width .25s}
    #kidotalk-book2 .b2-select{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:14px 0 12px}#kidotalk-book2 .b2-select label{font-weight:700}#kidotalk-book2 select{max-width:100%;padding:11px 14px;border:1px solid var(--line);border-radius:12px;background:#fff}
    #kidotalk-book2 .b2-units{display:flex;gap:8px;overflow-x:auto;padding:5px 2px 13px;scrollbar-width:thin}#kidotalk-book2 .b2-unit{flex:none;padding:9px 13px;border:1px solid var(--line);border-radius:14px;background:#fff;font-weight:700;cursor:pointer;transition:.18s}#kidotalk-book2 .b2-unit:hover{transform:translateY(-2px);border-color:var(--purple)}#kidotalk-book2 .b2-unit[aria-pressed=true]{color:#fff;border-color:transparent;background:var(--blue);box-shadow:0 5px 14px #3f69b233}
    #kidotalk-book2 .b2-title{display:flex;align-items:center;gap:12px;margin:10px 0 14px}#kidotalk-book2 .b2-title>span{font-size:34px}#kidotalk-book2 .b2-title h2{margin:0;font-size:24px}#kidotalk-book2 .b2-lesson-nav{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}#kidotalk-book2 .b2-lesson-nav button{padding:8px 12px;border:1px solid var(--line);border-radius:12px;background:#fff;cursor:pointer}#kidotalk-book2 .b2-lesson-nav button[aria-pressed=true]{background:var(--purple);color:white}
    #kidotalk-book2 .b2-card{padding:18px;border:1px solid var(--line);border-radius:19px;background:#fff;box-shadow:0 5px 20px #334b7909;overflow-wrap:anywhere}#kidotalk-book2 .b2-card h3{margin-bottom:5px;font-size:20px;color:#3f5591}#kidotalk-book2 .b2-goal{color:#555e72}#kidotalk-book2 .b2-actions{display:flex;flex-wrap:wrap;gap:9px;margin:16px 0}#kidotalk-book2 .b2-actions button,#kidotalk-book2 .b2-back{padding:9px 13px;border:1px solid #d9dfed;border-radius:12px;background:#f7f8fd;font-weight:700;cursor:pointer}#kidotalk-book2 .b2-actions button:hover,#kidotalk-book2 .b2-back:hover{background:#eeeaff;border-color:#9e8acb}
    #kidotalk-book2 .b2-vocab{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:11px;margin:16px 0;padding:0;list-style:none}#kidotalk-book2 .b2-vocab li{display:flex;flex-direction:column;align-items:center;gap:4px;min-height:150px;padding:11px;border:1px solid var(--line);border-radius:16px;background:#fafbff;text-align:center}#kidotalk-book2 .b2-illustration{display:grid;place-items:center;width:90px;height:88px;border-radius:17px;background:linear-gradient(145deg,#edf4ff,#f7edff 65%,#fff3d7);font-size:48px;line-height:1}#kidotalk-book2 .b2-vocab b{font-size:17px;direction:ltr;text-align:center}#kidotalk-book2 .b2-vocab small{color:#657086}
    #kidotalk-book2 .b2-question{margin-top:12px;padding:13px;border-radius:14px;background:#f5f7fc}#kidotalk-book2 .b2-question p{margin-bottom:9px}#kidotalk-book2 .b2-options{display:flex;flex-wrap:wrap;gap:8px}#kidotalk-book2 .b2-option,#kidotalk-book2 .b2-reveal,#kidotalk-book2 .b2-self-mark{padding:8px 12px;border:1px solid #d6deed;border-radius:11px;background:#fff;cursor:pointer}#kidotalk-book2 .b2-option:hover,#kidotalk-book2 .b2-reveal:hover,#kidotalk-book2 .b2-self-mark:hover{border-color:var(--blue);background:#f4f7ff}#kidotalk-book2 .b2-feedback{min-height:1.6em;margin:8px 0 0;font-weight:700}#kidotalk-book2 .b2-feedback.good{color:#16764e}#kidotalk-book2 .b2-feedback.try{color:#a24d27}#kidotalk-book2 .b2-sample{margin:8px 0 0;padding:9px 11px;border-inline-start:3px solid var(--teal);background:#effaf8}#kidotalk-book2 .b2-option:disabled{opacity:1;cursor:default}#kidotalk-book2 .b2-option[data-selected=true]{border:2px solid #16764e;background:#eaf8f0}
    #kidotalk-book2 .b2-reading{white-space:pre-line;line-height:2;direction:ltr;text-align:left;background:#eff6ff;border-radius:14px;padding:18px;font-size:18px}#kidotalk-book2 .b2-listening{padding:14px;border:1px solid var(--line);border-radius:12px;margin:16px 0}#kidotalk-book2 summary{cursor:pointer;font-weight:700}#kidotalk-book2 textarea{display:block;width:100%;min-height:76px;margin:12px 0;padding:12px;border:1px solid #bac7dc;border-radius:10px;resize:vertical}
    #kidotalk-book2 .b2-rating{direction:ltr;display:inline-flex;gap:2px;white-space:nowrap;font-family:Arial,sans-serif;font-size:20px;line-height:1.2}#kidotalk-book2 .b2-rating .on{color:#d39719}#kidotalk-book2 .b2-rating .off{color:#c9cbd4}#kidotalk-book2 .b2-lesson-score{display:flex;align-items:center;gap:8px;margin:12px 0;padding:10px 13px;border-radius:13px;background:#fff8e6;color:#69520c}
    #kidotalk-book2 .b2-flash-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin-top:14px}#kidotalk-book2 .b2-flash{display:flex;min-height:190px;flex-direction:column;justify-content:center;align-items:center;gap:5px;padding:14px;border:1px solid var(--line);border-radius:18px;background:white;text-align:center;box-shadow:0 5px 14px #34456c0d}#kidotalk-book2 .b2-flash .b2-illustration{width:112px;height:108px;font-size:62px}#kidotalk-book2 .b2-flash b{direction:ltr;font-size:18px}#kidotalk-book2 .b2-flash button{margin-top:5px;border:0;border-radius:10px;background:#edf4ff;padding:5px 10px;cursor:pointer}
    #kidotalk-book2 .b2-game-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin:14px 0}#kidotalk-book2 .b2-match-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:12px}#kidotalk-book2 .b2-game-card{min-height:82px;padding:10px;border:1px solid var(--line);border-radius:14px;background:#fff;text-align:center;font-weight:700;cursor:pointer;overflow-wrap:anywhere}#kidotalk-book2 .b2-game-card[aria-pressed=true]{outline:3px solid #8d78ce;background:#f4efff}#kidotalk-book2 .b2-game-card[data-matched=true]{border-color:#62b99a;background:#e8f8f0;cursor:default}#kidotalk-book2 .b2-game-card[data-wrong=true]{border-color:#df7b73;background:#fff0ef}#kidotalk-book2 .b2-game-art{display:block;font-size:35px;line-height:1.1;margin-bottom:4px}#kidotalk-book2 .b2-game-status{min-height:1.8em;font-weight:700;color:#43537a}
    #kidotalk-book2 .b2-progress-units{display:grid;gap:10px;margin-top:14px}#kidotalk-book2 .b2-progress-unit{padding:12px;border:1px solid var(--line);border-radius:14px;background:#fff}#kidotalk-book2 .b2-progress-unit summary{display:flex;justify-content:space-between;gap:8px}#kidotalk-book2 .b2-progress-lessons{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}#kidotalk-book2 .b2-progress-lessons span{padding:4px 8px;border-radius:9px;background:#f3f4f9;font-size:13px}#kidotalk-book2 .b2-local-note{margin-top:14px;color:#657086;font-size:13px}
    #kidotalk-book2 .b2-source{margin:16px 2px 0;color:#687084;font-size:12px}#kidotalk-book2 :is(button,a,select,textarea,summary):focus-visible{outline:3px solid #a55e00;outline-offset:3px}@media(max-width:650px){#kidotalk-book2 .b2-game-grid{grid-template-columns:repeat(2,minmax(0,1fr))}#kidotalk-book2 .b2-select{align-items:flex-start;flex-direction:column}#kidotalk-book2 select{width:100%}}@media(prefers-reduced-motion:reduce){#kidotalk-book2 *{transition:none!important;scroll-behavior:auto!important}}
  `;
  document.head.appendChild(style);
  mount.setAttribute("dir", "rtl");
  mount.innerHTML = '<div class="b2-shell"><p>در حال بارگذاری درس‌ها…</p></div>';

  function readSaved() {
    try { return JSON.parse(localStorage.getItem(storageKey) || "{\"lessons\":{}}") || { lessons: {} }; }
    catch (_) { return { lessons: {} }; }
  }
  let saved = readSaved();

  function render(data) {
    if (!data || !Array.isArray(data.units) || !data.units.length) throw new Error("محتوای کتاب پیدا نشد.");
    let current = 0;
    let lessonCurrent = 0;
    let mode = "lesson";
    let drafts = new Map();
    let sessionAnswers = Object.create(null);
    let game = null;
    mount.innerHTML = '<div class="b2-shell"><header class="b2-head"><span class="b2-mark" aria-hidden="true">📚</span><div><h1>Family and Friends 2</h1><p>درس، فلش‌کارت تصویری و بازی‌های تمرینی</p></div></header><section class="b2-progress" aria-label="پیشرفت کلی"><div class="b2-progress-top"><span>پیشرفت و ستاره‌های من</span><button type="button" data-mode="progress">دیدن کارنامه</button></div><div class="b2-progress-inner"></div></section><div class="b2-select"><label for="b2-unit-select">انتخاب یونیت</label><select id="b2-unit-select" aria-label="انتخاب یونیت"></select></div><nav class="b2-units" aria-label="یونیت‌های کتاب"></nav><main class="b2-content"></main></div>';
    const nav = mount.querySelector(".b2-units");
    const select = mount.querySelector("#b2-unit-select");
    select.setAttribute("dir", "ltr");

    data.units.forEach((unit, index) => {
      const option = document.createElement("option"); option.value = index; option.textContent = `Unit ${unit.number} · ${unit.title}`; select.appendChild(option);
      const button = document.createElement("button"); button.type = "button"; button.className = "b2-unit"; button.textContent = `Unit ${unit.number}`; button.setAttribute("aria-pressed", "false"); button.dataset.unitIndex = index; nav.appendChild(button);
    });

    function recordKey(unitNumber, lessonNumber) { return `${unitNumber}-${lessonNumber}`; }
    function recordFor(unitNumber, lessonNumber) { return saved.lessons[recordKey(unitNumber, lessonNumber)] || { stars: 0, done: false, activities: {} }; }
    function saveRecord(unitNumber, lessonNumber, stars, activity) {
      const key = recordKey(unitNumber, lessonNumber);
      const old = recordFor(unitNumber, lessonNumber);
      old.stars = Math.max(Number(old.stars) || 0, Math.max(0, Math.min(5, stars)));
      old.done = true;
      old.activities = old.activities || {};
      old.activities[activity] = true;
      old.updatedAt = Date.now();
      saved.lessons[key] = old;
      try { localStorage.setItem(storageKey, JSON.stringify(saved)); } catch (_) { /* The activity still works if storage is blocked. */ }
      refreshSummary();
      refreshLessonScore();
    }
    function stats() {
      const all = data.units.flatMap(unit => unit.lessons.map((lesson, index) => recordFor(unit.number, index + 1)));
      return { total: all.length, done: all.filter(x => x.done).length, stars: all.reduce((sum, x) => sum + (Number(x.stars) || 0), 0), max: all.length * 5 };
    }
    function starHTML(n) { n = Math.max(0, Math.min(5, Number(n) || 0)); return `<span class="b2-rating" role="img" aria-label="${n} از ۵ ستاره">${Array.from({length:5},(_,i)=>`<span class="${i<n?'on':'off'}" aria-hidden="true">★</span>`).join("")}</span>`; }
    function refreshSummary() {
      const s = stats(); const pct = s.max ? Math.round(s.stars / s.max * 100) : 0;
      const host = mount.querySelector(".b2-progress-inner"); if (host) host.innerHTML = `<div class="b2-progress-top"><span>${s.done} از ${s.total} بخش تکمیل‌شده</span><span>${s.stars} از ${s.max} ستاره</span></div><div class="b2-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:${pct}%"></i></div>`;
    }
    function refreshLessonScore() {
      const host = mount.querySelector(".b2-lesson-score");
      if (!host) return;
      const lesson = data.units[current].lessons[lessonCurrent];
      const s = recordFor(data.units[current].number, lessonCurrent + 1);
      host.innerHTML = `<b>ستاره‌های این درس</b>${starHTML(s.stars)}<span>${s.done ? "پیشرفت ذخیره شد" : "بعد از تمرین ستاره بگیر"}</span>`;
    }
    function wordsFor(unit, lesson) {
      let words = Array.isArray(lesson.vocabulary) ? lesson.vocabulary.slice() : [];
      if (!words.length && lesson.soundGroups) {
        for (const [sound, list] of Object.entries(lesson.soundGroups)) for (const en of list) words.push({ en, fa: `صدای ${sound}` });
      }
      if (words.length < 4) {
        for (const candidate of unit.lessons) for (const word of candidate.vocabulary || []) {
          if (!words.some(x => x.en.toLowerCase() === word.en.toLowerCase())) words.push(word);
        }
      }
      return words.slice(0, 6);
    }
    function cardWord(w) { return `<span class="b2-illustration" role="img" aria-label="${esc(w.en)}">${illustration(w.en)}</span>`; }
    function questionHTML(question, unitNumber, lessonNumber, questionIndex) {
      const id = `b2-${unitNumber}-${lessonNumber}-${questionIndex}`;
      if (question.type === "mcq") return `<div class="b2-question"><p><b>${question.skill === "listening" ? "پس از شنیدن:" : "تمرین:"}</b> <span dir="auto">${esc(question.prompt)}</span></p><div class="b2-options" role="group" aria-label="${esc(question.prompt)}">${question.options.map((option,oi) => `<button class="b2-option" dir="auto" type="button" data-correct="${esc(option === question.answer)}" data-feedback="${id}" data-q-index="${questionIndex}" data-option-index="${oi}">${esc(option)}</button>`).join("")}</div><p class="b2-feedback" id="${id}" role="status"></p></div>`;
      return `<div class="b2-question"><label for="${id}-input"><b>تمرین گفتاری/نوشتاری:</b> <span dir="auto">${esc(question.prompt)}</span></label><textarea id="${id}-input" dir="auto" placeholder="پاسخت را بنویس یا بلند بگو"></textarea><button class="b2-reveal" type="button" aria-expanded="false" aria-controls="${id}" data-reveal="${id}">دیدن نمونه پاسخ</button> <button class="b2-self-mark" type="button" data-self-complete="${id}">انجامش دادم ✓</button><p class="b2-sample" dir="auto" id="${id}" hidden>${esc(question.sample || "")}</p></div>`;
    }
    function progressView() {
      const s = stats();
      const rows = data.units.map(unit => {
        const marks = unit.lessons.map((lesson, index) => { const r = recordFor(unit.number, index + 1); return `<span>${index+1}. ${starHTML(r.stars)}</span>`; }).join("");
        const done = unit.lessons.filter((_, index) => recordFor(unit.number, index + 1).done).length;
        return `<details class="b2-progress-unit"><summary><b>Unit ${unit.number}: ${esc(unit.title)}</b><span>${done} / ${unit.lessons.length}</span></summary><div class="b2-progress-lessons">${marks}</div></details>`;
      }).join("");
      return `<article class="b2-card"><button type="button" class="b2-back" data-mode="lesson">بازگشت به درس</button><h3>کارنامهٔ یادگیری</h3><p>${s.done} بخش از ${s.total} بخش کامل شده و ${s.stars} ستاره از ${s.max} ستاره گرفته‌ای.</p>${starHTML(s.total ? Math.round(s.stars / s.total) : 0)}<div class="b2-progress-units">${rows}</div><p class="b2-local-note">پیشرفت در همین مرورگر و همین دستگاه ذخیره می‌شود؛ حساب کاربری یا همگام‌سازی ابری لازم نیست.</p></article>`;
    }
    function lessonView(unit, lesson) {
      const wordSet = wordsFor(unit, lesson);
      const vocab = wordSet.length ? `<h4>فلش‌کارت‌های واژه</h4><ul class="b2-vocab">${wordSet.map(w => `<li>${cardWord(w)}<b lang="en">${esc(w.en)}</b><small>${esc(w.fa || "")}</small></li>`).join("")}</ul>` : "";
      const sounds = lesson.soundGroups ? `<ul class="b2-vocab">${Object.entries(lesson.soundGroups).map(([g,words])=>`<li><span class="b2-illustration" aria-hidden="true">🔤</span><b>${esc(g)}</b><small lang="en" dir="ltr">${esc(words.join(", "))}</small></li>`).join("")}</ul>` : "";
      const passage = lesson.readingText ? `<h4>بخوان</h4><div class="b2-reading" lang="en">${esc(lesson.readingText)}</div>` : "";
      const listening = lesson.listeningScript ? `<details class="b2-listening"><summary>متن شنیداری برای همراه بزرگ‌تر</summary><p>این متن را دو بار آرام بخوانید؛ کودک هنگام پاسخ دادن متن را نبیند.</p><div class="b2-reading" lang="en">${esc(lesson.listeningScript)}</div></details>` : "";
      const rec = recordFor(unit.number, lessonCurrent + 1);
      return `<article class="b2-card"><h3>درس ${lessonCurrent+1}: ${esc(lesson.title)}</h3><p class="b2-goal">${esc(lesson.goal)}</p><div class="b2-lesson-score"><b>ستاره‌های این درس</b>${starHTML(rec.stars)}<span>${rec.done ? "پیشرفت ذخیره شد" : "بعد از تمرین ستاره بگیر"}</span></div><div class="b2-actions"><button type="button" data-mode="flash">🃏 فلش‌کارت تصویری</button><button type="button" data-mode="match">🔗 تطبیق تصویر و واژه</button><button type="button" data-mode="memory">🧠 بازی حافظه</button></div>${vocab}${sounds}<ol>${(lesson.teach || []).map(step => `<li dir="auto">${esc(step)}</li>`).join("")}</ol>${passage}${listening}${(lesson.practice || []).map((q,qi)=>questionHTML(q,unit.number,lessonCurrent+1,qi)).join("")}</article>`;
    }
    function flashView(words, unit, lesson) {
      return `<article class="b2-card"><button type="button" class="b2-back" data-mode="lesson">← برگشت به درس</button><h3>فلش‌کارت‌های تصویری · Unit ${unit.number} · درس ${lessonCurrent+1}</h3><p>به تصویر نگاه کن، واژهٔ انگلیسی را بخوان و معنی‌اش را به یاد بیاور.</p><div class="b2-flash-grid">${words.map(w => `<div class="b2-flash">${cardWord(w)}<b lang="en">${esc(w.en)}</b><span>${esc(w.fa || "")}</span><button type="button" data-speak="${esc(w.en)}">🔊 شنیدن واژه</button></div>`).join("")}</div></article>`;
    }
    function gameView(words, type, unit, lesson) {
      if (!game || game.type !== type) {
        if (type === "match") game = { type, selected: { picture: null, word: null }, matched: new Set(), wrong: 0, busy: false };
        else {
          const cards = mix(words.flatMap((w, index) => [{ pair: index, side: "picture", word: w }, { pair: index, side: "word", word: w }]));
          game = { type, cards, open: [], matched: new Set(), wrong: 0, busy: false };
        }
      }
      const status = game.matched.size === words.length ? `تمام جفت‌ها را پیدا کردی! ${starHTML(Math.max(1, 5 - Math.ceil(game.wrong / 2)))}` : `جفت‌های پیدا شده: ${game.matched.size} از ${words.length} · اشتباه‌ها: ${game.wrong}`;
      if (type === "match") {
        const left = mix(words.map((w,i)=>({w,i}))).map(({w,i}) => `<button type="button" class="b2-game-card" data-match-side="picture" data-match-id="${i}" aria-pressed="${game.selected.picture === i}" data-matched="${game.matched.has(i)}" ${game.matched.has(i)?"disabled":""}><span class="b2-game-art" role="img" aria-label="${esc(w.en)}">${illustration(w.en)}</span></button>`).join("");
        const right = mix(words.map((w,i)=>({w,i}))).map(({w,i}) => `<button type="button" class="b2-game-card" data-match-side="word" data-match-id="${i}" aria-pressed="${game.selected.word === i}" data-matched="${game.matched.has(i)}" ${game.matched.has(i)?"disabled":""}><span lang="en" dir="ltr">${esc(w.en)}</span><br><small>${esc(w.fa||"")}</small></button>`).join("");
        return `<article class="b2-card"><button type="button" class="b2-back" data-mode="lesson">← برگشت به درس</button><h3>تطبیق تصویر و واژه</h3><p>یک تصویر و واژهٔ هم‌معنی‌اش را انتخاب کن.</p><div class="b2-match-grid"><div class="b2-game-grid">${left}</div><div class="b2-game-grid">${right}</div></div><p class="b2-game-status" role="status">${status}</p></article>`;
      }
      const cards = game.cards.map((card,index) => {
        const open = game.open.includes(index) || game.matched.has(card.pair);
        const face = card.side === "picture" ? `<span class="b2-game-art">${illustration(card.word.en)}</span>` : `<span lang="en" dir="ltr">${esc(card.word.en)}</span>`;
        return `<button type="button" class="b2-game-card" data-memory-index="${index}" aria-label="${open ? esc(card.word.en) : "کارت پنهان"}" aria-pressed="${open}" data-matched="${game.matched.has(card.pair)}" ${open || game.busy ? "disabled" : ""}>${open ? face : "❔"}</button>`;
      }).join("");
      return `<article class="b2-card"><button type="button" class="b2-back" data-mode="lesson">← برگشت به درس</button><h3>بازی حافظهٔ تصویری</h3><p>کارت‌ها را یکی‌یکی برگردان و تصویر را با واژهٔ انگلیسی جفت کن.</p><div class="b2-game-grid">${cards}</div><p class="b2-game-status" role="status">${status}</p></article>`;
    }
    function drawActivity() {
      const unit = data.units[current], lesson = unit.lessons[lessonCurrent], words = wordsFor(unit, lesson);
      const host = mount.querySelector(".b2-content");
      const body = mode === "flash" ? flashView(words,unit,lesson) : mode === "match" || mode === "memory" ? gameView(words,mode,unit,lesson) : progressView();
      host.querySelector(".b2-panel").innerHTML = body;
    }
    function show(index, lessonIndex = 0, nextMode = "lesson") {
      mount.querySelectorAll("textarea").forEach(el => drafts.set(el.id, el.value));
      current = Math.max(0, Math.min(data.units.length - 1, Number(index) || 0));
      const unit = data.units[current];
      lessonCurrent = Math.max(0, Math.min(unit.lessons.length - 1, Number(lessonIndex) || 0));
      mode = nextMode;
      game = null;
      select.value = String(current);
      nav.querySelectorAll(".b2-unit").forEach(button => button.setAttribute("aria-pressed", String(Number(button.dataset.unitIndex) === current)));
      const selectedUnit = nav.querySelector('[aria-pressed="true"]'); if (selectedUnit) selectedUnit.scrollIntoView({block:"nearest",inline:"nearest"});
      const lesson = unit.lessons[lessonCurrent];
      const lessonNav = `<nav class="b2-lesson-nav" aria-label="درس‌های یونیت">${unit.lessons.map((l,i)=>`<button type="button" data-lesson="${i}" aria-pressed="${i===lessonCurrent}">${i+1}. ${esc(l.title)}</button>`).join("")}</nav>`;
      const panel = mode === "lesson" ? lessonView(unit,lesson) : mode === "flash" || mode === "match" || mode === "memory" ? "" : progressView();
      mount.querySelector(".b2-content").innerHTML = `<div class="b2-title"><span aria-hidden="true">${esc(unit.icon || "📚")}</span><h2 dir="auto">Unit ${unit.number}: ${esc(unit.title)}</h2></div>${lessonNav}<div class="b2-panel">${panel}</div><p class="b2-source">Kidotalk · درس و تمرین تکمیلی Family and Friends 2</p>`;
      mount.querySelectorAll("textarea").forEach(el => { el.value = drafts.get(el.id) || ""; });
      mount.querySelectorAll(".b2-options").forEach(group => {
        const qIndex = Number(group.querySelector("[data-q-index]")?.dataset.qIndex);
        const k = `${unit.number}-${lessonCurrent+1}-${qIndex}`;
        const attempt = sessionAnswers[k];
        if (attempt && attempt.resolved) {
          const right = group.querySelector('[data-correct="true"]');
          if (right) { right.disabled = true; right.dataset.selected = "true"; }
          group.querySelectorAll("button").forEach(button => { button.disabled = true; });
          const feedback = mount.querySelector(`#${CSS.escape(right ? right.dataset.feedback : "")}`); if (feedback) { feedback.textContent = "آفرین، درست است!"; feedback.className = "b2-feedback good"; }
        }
      });
      refreshSummary();
      if (mode === "flash" || mode === "match" || mode === "memory") drawActivity();
    }
    function onOption(option) {
      const unit = data.units[current], lesson = unit.lessons[lessonCurrent];
      const qIndex = Number(option.dataset.qIndex), k = `${unit.number}-${lessonCurrent+1}-${qIndex}`;
      const attempt = sessionAnswers[k] || (sessionAnswers[k] = { first: null, resolved: false });
      const correct = option.dataset.correct === "true";
      const feedback = mount.querySelector(`#${CSS.escape(option.dataset.feedback)}`);
      if (!correct) {
        if (attempt.first === null) attempt.first = false;
        feedback.textContent = "هنوز درست نیست؛ یک بار دیگر تلاش کن."; feedback.className = "b2-feedback try";
        return;
      }
      if (attempt.first === null) attempt.first = true;
      attempt.resolved = true;
      feedback.textContent = "آفرین، درست است!"; feedback.className = "b2-feedback good";
      option.dataset.selected = "true";
      option.parentElement.querySelectorAll("button").forEach(button => { button.disabled = true; });
      const mcqs = (lesson.practice || []).map((x,i)=>({x,i})).filter(({x})=>x.type === "mcq");
      if (mcqs.length && mcqs.every(({i})=>sessionAnswers[`${unit.number}-${lessonCurrent+1}-${i}`]?.resolved)) {
        const firstCorrect = mcqs.filter(({i})=>sessionAnswers[`${unit.number}-${lessonCurrent+1}-${i}`]?.first === true).length;
        const score = Math.max(1, Math.round(firstCorrect / mcqs.length * 5));
        saveRecord(unit.number,lessonCurrent+1,score,"quiz");
      }
    }
    function openActivity(type) { show(current,lessonCurrent,type); }
    function gameSolved() {
      const stars = Math.max(1, 5 - Math.ceil(game.wrong / 2));
      saveRecord(data.units[current].number,lessonCurrent+1,stars,game.type);
    }
    function answerMatch(button) {
      if (!game || game.busy || button.dataset.matched === "true") return;
      const side = button.dataset.matchSide, id = Number(button.dataset.matchId);
      game.selected[side] = id;
      if (game.selected.picture !== null && game.selected.word !== null) {
        const a = game.selected.picture, b = game.selected.word;
        game.selected = {picture:null,word:null};
        if (a === b) {
          game.matched.add(a);
          if (game.matched.size === wordsFor(data.units[current],data.units[current].lessons[lessonCurrent]).length) gameSolved();
        } else {
          game.wrong++; game.busy = true;
          drawActivity();
          const panel = mount.querySelector(".b2-panel"); if (panel) panel.querySelector(".b2-game-status").textContent = "این دو با هم جور نیستند؛ دوباره امتحان کن.";
          setTimeout(()=>{ if (mode === "match" && game) { game.busy=false; drawActivity(); } },700);
          return;
        }
      }
      drawActivity();
    }
    function answerMemory(button) {
      if (!game || game.busy || button.disabled) return;
      const index = Number(button.dataset.memoryIndex), card = game.cards[index];
      if (!card || game.open.includes(index)) return;
      game.open.push(index);
      if (game.open.length === 2) {
        const [a,b] = game.open.map(i=>game.cards[i]);
        if (a.pair === b.pair && a.side !== b.side) {
          game.matched.add(a.pair); game.open = [];
          if (game.matched.size === wordsFor(data.units[current],data.units[current].lessons[lessonCurrent]).length) gameSolved();
        } else {
          game.wrong++; game.busy = true;
          drawActivity();
          setTimeout(()=>{ if (mode === "memory" && game) { game.open=[]; game.busy=false; drawActivity(); } },800);
          return;
        }
      }
      drawActivity();
    }

    select.addEventListener("change", () => show(Number(select.value),0));
    nav.addEventListener("click", event => { const button = event.target.closest("[data-unit-index]"); if (button) show(Number(button.dataset.unitIndex),0); });
    mount.addEventListener("click", event => {
      const modeButton = event.target.closest("[data-mode]");
      if (modeButton) { const next = modeButton.dataset.mode; if (next === "lesson") show(current,lessonCurrent,"lesson"); else if (next === "progress") show(current,lessonCurrent,"progress"); else openActivity(next); return; }
      const lessonButton = event.target.closest("[data-lesson]");
      if (lessonButton) { show(current,Number(lessonButton.dataset.lesson),"lesson"); return; }
      const option = event.target.closest(".b2-option"); if (option) { onOption(option); return; }
      const matchButton = event.target.closest("[data-match-side]"); if (matchButton) { answerMatch(matchButton); return; }
      const memoryButton = event.target.closest("[data-memory-index]"); if (memoryButton) { answerMemory(memoryButton); return; }
      const speakButton = event.target.closest("[data-speak]"); if (speakButton) { if ("speechSynthesis" in window) { const utterance = new SpeechSynthesisUtterance(speakButton.dataset.speak); utterance.lang="en-US"; window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance); } return; }
      const selfMark = event.target.closest("[data-self-complete]");
      if (selfMark) { selfMark.textContent = "ثبت شد ✓"; selfMark.disabled = true; saveRecord(data.units[current].number,lessonCurrent+1,1,"self-check"); return; }
      const reveal = event.target.closest("[data-reveal]");
      if (reveal) { const sample=mount.querySelector(`#${CSS.escape(reveal.dataset.reveal)}`); const expanded=reveal.getAttribute("aria-expanded")==="true"; reveal.setAttribute("aria-expanded",String(!expanded)); sample.hidden=expanded; reveal.textContent=expanded?"دیدن نمونه پاسخ":"پنهان کردن پاسخ"; }
    });
    mount.addEventListener("input", event => { if (event.target.matches("textarea")) drafts.set(event.target.id,event.target.value); });
    refreshSummary();
    show(0);
  }

  const embedded = document.getElementById("kidotalk-book2-data");
  const dataPromise = embedded ? Promise.resolve().then(() => JSON.parse(embedded.textContent)) : fetch(dataUrl).then(response => { if (!response.ok) throw new Error("دریافت محتوای کتاب ناموفق بود."); return response.json(); });
  dataPromise.then(render).catch(error => { mount.innerHTML = `<div class="b2-shell"><h2>محتوای کتاب بارگذاری نشد</h2><p>مطمئن شو فایل JSON کنار فایل نمایش درس‌ها قرار دارد و سایت از طریق هاست یا سرور محلی باز شده است.</p><small>${esc(error.message)}</small></div>`; });
})();
